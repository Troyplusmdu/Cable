﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using DataAccessLayer;
using System.Data.OleDb;

public partial class ModifyInstCash : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string connStr = string.Empty;

        if (Session["Company"] != null)
            connStr = System.Configuration.ConfigurationManager.ConnectionStrings[Session["Company"].ToString()].ToString();
        else
            Response.Redirect("~/frm_Login.aspx");

        string dbfileName = connStr.Remove(0, connStr.LastIndexOf(@"App_Data\") + 9);
        dbfileName = dbfileName.Remove(dbfileName.LastIndexOf(";Persist Security Info"));

        BusinessLogic objChk = new BusinessLogic();
        if (objChk.CheckForOffline(Server.MapPath("Offline\\" + dbfileName + ".offline")))
        {
            grdCash.Columns[6].Visible = false;
        }

        srcArea.ConnectionString = connStr;
        srcBook.ConnectionString = connStr;
        srcReason.ConnectionString = connStr;


    }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        grdCash.RowUpdated += new GridViewUpdatedEventHandler(ddBook_SelectedIndexChanged);
        ObjectDataSource1.SelectParameters.Add(new SessionParameter("connection", "Company"));
        ObjectDataSource1.SelectParameters.Add(new ControlParameter("billNo", TypeCode.String, txtBillNo.UniqueID, "Text"));
        ObjectDataSource1.SelectParameters.Add(new ControlParameter("bookID", TypeCode.Int32, ddBook.UniqueID, "SelectedValue"));
    }

    protected void grdCash_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {

    }
    protected void grdCash_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
    protected void grdCash_RowEditing(object sender, GridViewEditEventArgs e)
    {
        //grdCash.EditIndex = e.NewEditIndex;
        //GridViewRow editingRow = grdCash.Rows[e.NewEditIndex];
        //DropDownList ddlPbx = (editingRow.FindControl("ddReason") as DropDownList);
        //string val = grdCash.Rows[grdCash.EditIndex].Cells[5].ToString();

        //if (ddlPbx != null)
        //{
        //    if (ddlPbx.Items.FindByValue(val) != null)
        //        ddlPbx.Items.FindByValue(val).Selected = true;
        //    else
        //        ddlPbx.ClearSelection();
        //} 

    }

    private string GetMonth(int month)
    {
        string Retmonth = string.Empty;

        switch (month)
        {
            case 1:
                Retmonth = "January";
                break;
            case 2:
                Retmonth = "February";
                break;
            case 3:
                Retmonth = "March";
                break;
            case 4:
                Retmonth = "April";
                break;
            case 5:
                Retmonth = "May";
                break;
            case 6:
                Retmonth = "June";
                break;
            case 7:
                Retmonth = "July";
                break;
            case 8:
                Retmonth = "August";
                break;
            case 9:
                Retmonth = "September";
                break;
            case 10:
                Retmonth = "October";
                break;
            case 11:
                Retmonth = "November";
                break;
            default:
                Retmonth = "December";
                break;
        }

        return Retmonth;
    }

    protected void grdCash_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        string bookName = ((TextBox)grdCash.Rows[e.RowIndex].FindControl("txtBillNo")).Text;
        string code = ((TextBox)grdCash.Rows[e.RowIndex].FindControl("txtCode")).Text;
        string amount = ((TextBox)grdCash.Rows[e.RowIndex].FindControl("txtAmount")).Text;
        string datepaid = ((TextBox)grdCash.Rows[e.RowIndex].FindControl("txtDatePaid")).Text;
        string area = ((DropDownList)grdCash.Rows[e.RowIndex].FindControl("ddArea")).SelectedValue;
        string id = grdCash.DataKeys[e.RowIndex].Value.ToString();

        DateTime tempDatePaid = DateTime.Parse(datepaid);
        DateTime tempDateEntered = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));


        if (tempDatePaid > tempDateEntered)
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Date Paid Cannot be Greater than Todays Date.');", true);
            return;
        }

        string connStr = string.Empty;

        string BookID = ddBook.SelectedValue;

        if (Session["Company"] != null)
            connStr = System.Configuration.ConfigurationManager.ConnectionStrings[Session["Company"].ToString()].ToString();
        else
            Response.Redirect("~/frm_Login.aspx");

        BusinessLogic bll = new BusinessLogic();
        string recondate = datepaid;

        if (!bll.IsValidDate(connStr, Convert.ToDateTime(recondate)))
        {
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Date is invalid. Please contact Administrator.')", true);
            grdCash.EditIndex = e.RowIndex;
            return;
        }

        DataSet ds = bll.IsDatePaidValid(connStr,int.Parse( BookID));

        if (ds != null)
        {
            string month = ds.Tables[0].Rows[0]["MonthPaid"].ToString();

            DateTime paidDate = DateTime.Parse(datepaid);

            if (month != (paidDate.Year.ToString() + paidDate.Month.ToString()))
            {
                string mnth = month.Remove(0,4);
                string year = month.Remove(4);
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('DatePaid should be in the month of " + GetMonth(int.Parse(mnth)) +" "+ year + ". Please check Book details.');", true);
                return;
            }
        }


        using (OleDbConnection connection = new OleDbConnection(connStr))
        {
            OleDbCommand command = new OleDbCommand();
            OleDbTransaction transaction = null;
            OleDbDataAdapter adapter = null;

            // Set the Connection to the new OleDbConnection.
            command.Connection = connection;

            // Open the connection and execute the transaction.
            try
            {
                connection.Open();

                // Start a local transaction with ReadCommitted isolation level.
                transaction = connection.BeginTransaction(IsolationLevel.ReadCommitted);

                // Assign transaction object for a pending local transaction.
                command.Connection = connection;
                command.Transaction = transaction;

                command.CommandText = string.Format("Select Amount from tblBook Where BookID={0}", BookID);
                int BookCash = (int)command.ExecuteScalar();

                command.CommandText = string.Format("Select code,area,amount FROM InstallationCash Where ID={0}", id);
                DataSet data = new DataSet();
                adapter = new OleDbDataAdapter(command);
                adapter.Fill(data);

                if (data != null)
                {
                    if (data.Tables[0].Rows.Count == 1)
                    {
                        string old_code = data.Tables[0].Rows[0]["code"].ToString();
                        string old_area = data.Tables[0].Rows[0]["area"].ToString();
                        int old_amount = int.Parse(data.Tables[0].Rows[0]["amount"].ToString());

                        command.CommandText = string.Format("Select SUM(amount) as BookAmount from CashDetails Where BookID={0}", BookID);
                        string cashtotalamount = command.ExecuteScalar().ToString();

                        command.CommandText = "Select SUM(amount) as InstAmount from InstallationCash Where BookID= " + BookID;
                        string insttotalamount = command.ExecuteScalar().ToString();

                        command.CommandText = string.Format("Select EndEntry from tblBook Where BookID={0}", BookID);
                        int BookEndEntry = (int)command.ExecuteScalar();

                        command.CommandText = string.Format("Select MAX(billno) as Bill from CashDetails Where BookID={0}", BookID);
                        string CashEndEntry = command.ExecuteScalar().ToString();

                        double cashTotalAmount = 0;
                        double InstTotalAmount = 0;

                        if (cashtotalamount != "")
                            cashTotalAmount = double.Parse(cashtotalamount);

                        if (insttotalamount != "")
                            InstTotalAmount = double.Parse(insttotalamount);

                        if (((cashTotalAmount + InstTotalAmount) - old_amount + double.Parse(amount)) > BookCash)
                        {
                            transaction.Rollback();
                            ScriptManager.RegisterStartupScript(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Cash you entered is more than the Total Cash for this Book. Please try again!');", true);
                            return;
                        }
                        else if ((((cashTotalAmount + InstTotalAmount) - old_amount + double.Parse(amount)) == BookCash) && (BookEndEntry == int.Parse(CashEndEntry)))
                        {
                            command.CommandText = string.Format("UPDATE tblBook SET BookStatus = 'Closed' WHERE BookID = {0}", BookID);
                            command.ExecuteNonQuery();
                            ddBook.Items.Remove(new ListItem(ddBook.SelectedItem.Text, ddBook.SelectedValue));
                            errorDisplay.AddItem("You have entered the Maximum Amount for this Book. Book is closed now.", DisplayIcons.GreenTick, false);
                        }

                        command.CommandText = string.Format("UPDATE InstallationCash SET code={0},area='{1}',amount={2},EnteredDate=Format('{3}', 'dd/mm/yyyy') Where ID={4}", code, area.Replace("'", "''"), amount, datepaid, id);
                        command.ExecuteNonQuery();

                    }
                    else
                    {
                        throw new Exception("Too Many rows returned from the query");
                    }
                }

                transaction.Commit();

            }
            catch (Exception ex)
            {
                try
                {
                    // Attempt to roll back the transaction.
                    transaction.Rollback();
                    errorDisplay.AddItem("Exception while Adding Cash : " + ex.Message + ex.StackTrace, DisplayIcons.Error, false);
                }
                catch (Exception ep)
                {
                    // Do nothing here; transaction is not active.
                    errorDisplay.AddItem("Exception while Adding Cash : " + ep.Message + ep.StackTrace, DisplayIcons.Error, false);
                }
            }
        }
    }
    protected void grdCash_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Pager)
        {
            PresentationUtils.SetPagerButtonStates(grdCash, e.Row, this);
        }
    }
    protected void grdCash_DataBound(object sender, EventArgs e)
    {

    }
    protected void grdCash_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

        }
    }
    protected void lnkBtnSearch_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void ObjectDataSource1_Updating(object sender, ObjectDataSourceMethodEventArgs e)
    {
        e.Cancel = true;
    }
    protected void ddBook_SelectedIndexChanged(object sender, EventArgs e)
    {
        string connStr = string.Empty;

        if (Session["Company"] != null)
            connStr = Session["Company"].ToString();
        else
            Response.Redirect("~/frm_Login.aspx");

        if (ddBook.SelectedValue != "0")
        {
            try
            {
                BusinessLogic objBus = new BusinessLogic();

                DBManager manager = new DBManager(DataProvider.OleDb);
                manager.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[connStr].ConnectionString;
                manager.Open();

                object TotalCash = manager.ExecuteScalar(CommandType.Text, "Select Amount From tblBook Where BookID=" + ddBook.SelectedValue);

                object CashEntered = manager.ExecuteScalar(CommandType.Text, "Select SUM(amount) as amount from CashDetails Where BookID= " + ddBook.SelectedValue);

                object InstCashEntered = manager.ExecuteScalar(CommandType.Text, "Select SUM(amount) as amount from InstallationCash Where BookID= " + ddBook.SelectedValue);

                int TotalKash = 0;
                int EntetedKash = 0;
                int InstKashEntered = 0;

                if (TotalCash != null)
                {
                    if (TotalCash.ToString() != "")
                    {
                        TotalKash = int.Parse(TotalCash.ToString());
                    }
                    lblTotalAmount.Text = TotalKash.ToString();
                }

                if (InstCashEntered != null)
                {
                    if (InstCashEntered.ToString() != "")
                    {
                        InstKashEntered = int.Parse(InstCashEntered.ToString());
                    }
                }

                if (CashEntered != null)
                {
                    if (CashEntered.ToString() != "")
                    {
                        EntetedKash = int.Parse(CashEntered.ToString());
                    }
                }

                EntetedKash = EntetedKash + InstKashEntered;
                lblCashEnteted.Text = EntetedKash.ToString();

                int cashRem = TotalKash - EntetedKash;
                lblCashRem.Text = cashRem.ToString();

                manager.Dispose();

            }
            catch (Exception ex)
            {
                errorDisplay.AddItem("Exception :" + ex.Message + ex.StackTrace, DisplayIcons.Error, false);
            }
        }
    }
    protected void grdCash_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {

    }

}
